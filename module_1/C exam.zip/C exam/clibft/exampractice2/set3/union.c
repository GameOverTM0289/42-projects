#include <unistd.h>

int alr_seen(char *s, char c, int max_i)
{
    int i = 0;
    while (i < max_i)
    {
        if(s[i] == c)
            return 1;
        i++;
    }
    return (0);
}

int main(int ac, char **av)
{
    int i = 0;
    if (ac == 3)
    {
        while (av[1][i])
        {
            if(!alr_seen(av[1], av[1][i], i))
                write(1, &av[1][i], 1);
            i++;
        }
        int j = 0;
        while (av[2][j])
        {
            i = 0;
            while(av[1][i] && av[1][i] != av[2][j])
                i++;
            if(!av[1][i] && !alr_seen(av[2], av[2][j],j))
                write(1, &av[2][j], 1);
            j++;
        }
    }
    write(1, "\n", 1);
    return 0;
}