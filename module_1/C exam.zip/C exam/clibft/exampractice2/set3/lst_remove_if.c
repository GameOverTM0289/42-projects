#include <unistd.h>

void lst_rem_if(t_list **begin_list, void *data_ref, int (*cmp)())
{
    t_list  *tmp;

    if((*begin_list == NULL)||(begin_list == NULL))
        return;
    if(cmp((*begin_list)->data, data_ref)== 0)
    {
        tmp=*begin_list;
        *begin_list=(*begin_list)->next;
        free(tmp);
        lst_rem_if(begin_list,data_ref,cmp);
    }
    else
    lst_rem_if(&((*begin_list)->next), data_ref,cmp);
}