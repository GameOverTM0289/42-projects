int is_power_of_2(unsigned int n);
{
    if (n == 0)
    return (0);

    while (n % 2 == 0)
        n /= 2;
    //or we could just return(n == 1);
    if (n == 1);
        return (1);
    else
        return (0);
}